const postForm = document.getElementById('postForm');
const postsContainer = document.getElementById('posts');

postForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const message = document.getElementById('message').value;

    const response = await fetch('http://localhost:5000/posts', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message }),
    });

    if (response.ok) {
        document.getElementById('message').value = '';
        loadPosts();
    }
});

async function loadPosts() {
    const response = await fetch('http://localhost:5000/posts');
    const posts = await response.json();

    postsContainer.innerHTML = '';
    posts.forEach(post => {
        const postElement = document.createElement('div');
        postElement.classList.add('post');
        postElement.innerText = post.message;
        postsContainer.appendChild(postElement);
    });
}

window.onload = loadPosts;
